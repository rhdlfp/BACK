package com.example.springsocial.comunity.heart.entity;

import javax.persistence.Entity;
import javax.persistence.Table;

import com.example.springsocial.comunity.Comunity;
import com.example.springsocial.model.User;
import lombok.AccessLevel;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;

@Getter
@NoArgsConstructor(access = AccessLevel.PROTECTED)
@Entity
@Table(name = "heart")
public class Heart {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "heart_id")
	private Long id;

	@ManyToOne(fetch = LAZY)
	@JoinColumn(name = "member_id")
	private Member member;

	@ManyToOne(fetch = LAZY)
	@JoinColumn(name = "board_id")
	private Comunity comunity;

	@Builder
	public Heart(User member, Comunity cumunity) {
		this.member = member;
		this.board = board;
	}
}
