package com.example.springsocial.comunity;

public enum ComunityAttachmentType {
    IMAGE, GENERAL
}
