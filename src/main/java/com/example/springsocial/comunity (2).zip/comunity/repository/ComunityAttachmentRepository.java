package com.example.springsocial.comunity.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.springsocial.comunity.ComunityAttachment;

public interface ComunityAttachmentRepository extends JpaRepository<ComunityAttachment, Long> {
}
