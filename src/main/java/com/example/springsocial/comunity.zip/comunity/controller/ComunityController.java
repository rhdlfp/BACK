package com.example.springsocial.comunity.controller;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.springsocial.comunity.Comunity;
import com.example.springsocial.comunity.repository.ComunityRepository;
import com.example.springsocial.comunity.service.ComunityService;
import com.example.springsocial.exception.ResourceNotFoundException;


@CrossOrigin(origins = "http://localhost:3000")
@RestController
@RequestMapping("/api")
public class ComunityController {
	
	@Autowired
	private ComunityService comunityService;
	@Autowired
	private ComunityRepository comunityRepository;

	@GetMapping("/comunity")
	public ResponseEntity<Map> getAllBoards(@RequestParam(value = "p_num", required=false) Integer p_num) {
		if (p_num == null || p_num <= 0) p_num = 1;
		
		return comunityService.getPagingBoard(p_num);
	}
  
	// get all board 
//	@GetMapping("/comunity")
//	public List<Comunity> getAllBoards() {
//		
//		return comunityService.getAllBoard();
//	}
//	
	@PostMapping("/comunity")
	public Comunity createBoard(@RequestBody Comunity comunity) {
		System.out.println("@PostMapping(\"/comunity\")");
		System.out.println(comunity.toString());
		return comunityService.createBoard(comunity);
	}
	
	@GetMapping("/comunity/{no}")
	public ResponseEntity<Comunity> getBoardByno(@PathVariable Integer no) {
		return comunityService.getBoard(no);
	}
	
	@PutMapping("/comunity/{no}")
	public ResponseEntity<Comunity> updateBoardByno(@PathVariable Integer no, @RequestBody Comunity comunity) {
		return comunityService.updateBoard(no, comunity);
	}
	
	@DeleteMapping("comunity/{no}")
	public ResponseEntity<Map<String, Boolean>> deleteBoardByNo(@PathVariable Integer no){
		return comunityService.deleteBoard(no);
	}
	
	// 이 부분은 다른 코드와 함께 필요한 주석과 함께 있는 메소드이므로 해당 부분에 추가해주시기 바랍니다.
    @PutMapping("/comunity/incrementCounts/{no}")
    public ResponseEntity<Comunity> incrementCounts(@PathVariable(value = "no") Integer no) {
        Comunity comunity = comunityRepository.findById(no)
                .orElseThrow(() -> new ResourceNotFoundException("Comunity", "no", no));

        comunity.setCounts(comunity.getCounts() + 1); // counts 값을 1씩 증가시킴

        final Comunity updatedComunity = comunityRepository.save(comunity);
        return ResponseEntity.ok(updatedComunity);
    }
	
}
