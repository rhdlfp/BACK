package com.example.springsocial.comunity.comment.dto;

import lombok.Getter;

@Getter
public class CommentRequestDto {
    private Long articleId;
    private String body;
}