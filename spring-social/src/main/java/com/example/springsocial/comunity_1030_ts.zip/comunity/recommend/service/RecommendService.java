package com.example.springsocial.comunity.recommend.service;

import java.util.List;

import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.example.springsocial.article.Article;
import com.example.springsocial.article.repository.ArticleRepository;
import com.example.springsocial.comunity.Comunity;
import com.example.springsocial.comunity.recommend.Recommend;
import com.example.springsocial.comunity.recommend.dto.RecommendDTO;
import com.example.springsocial.comunity.recommend.repository.RecommendRepository;
import com.example.springsocial.comunity.repository.ComunityRepository;
import com.example.springsocial.model.User;
import com.example.springsocial.repository.UserRepository;

import lombok.RequiredArgsConstructor;

@Service
@Transactional(readOnly = true)
@RequiredArgsConstructor
public class RecommendService {
	private final RecommendRepository recommendRepository;
    private final UserRepository userRepository;
    private final ArticleRepository articleRepository;
    
    public RecommendDTO allRecommend(Long id) {
        Article article = articleRepository.findById(id).orElseThrow(() -> new RuntimeException("글이 없습니다."));
        List<Recommend> recommends = recommendRepository.findAllByArticle(article);
        int size = recommends.size();
        if (size == 0) {
            return RecommendDTO.noOne();
        }

        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();

        if (authentication == null || "anonymousUser".equals(authentication.getPrincipal())) {
            return new RecommendDTO(size, false);
        } else {
            User authenticatedUser = userRepository.findById(Long.parseLong(authentication.getPrincipal().toString())).orElseThrow();
            boolean result = recommends.stream().anyMatch(recommend -> recommend.getUser().equals(authenticatedUser));
            return new RecommendDTO(size, result);
        }
    }
    
    @Transactional
    public void createRecommend(Long id) {
    	User user = userRepository.findById(id)
        .orElseThrow(() -> new RuntimeException("로그인 유저 정보가 없습니다"));
    	Article article = articleRepository.findById(id).orElseThrow(() -> new RuntimeException("글이 없습니다."));

        Recommend recommend = new Recommend(user, article);
        recommendRepository.save(recommend);
    }
    
    @Transactional
    public void removeRecommend(Long id) {
    	User user = userRepository.findById(id)
        .orElseThrow(() -> new RuntimeException("로그인 유저 정보가 없습니다"));
       
    	Article article = articleRepository.findById(id).orElseThrow(() -> new RuntimeException("글이 없습니다."));
    	Recommend recommend = recommendRepository.findAllByArticle(article)
                .stream()
                .filter(r -> r.getUser().equals(user))
                .findFirst()
                .orElseThrow(() ->  new RuntimeException("추천이 없습니다."));

    	recommendRepository.delete(recommend);
    }

    
}
