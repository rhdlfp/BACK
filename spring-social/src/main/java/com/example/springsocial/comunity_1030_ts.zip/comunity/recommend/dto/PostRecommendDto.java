package com.example.springsocial.comunity.recommend.dto;

import lombok.Data;

@Data
public class PostRecommendDto {
	private Long id;
}
