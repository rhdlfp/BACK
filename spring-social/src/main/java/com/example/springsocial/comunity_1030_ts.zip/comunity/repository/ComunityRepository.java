package com.example.springsocial.comunity.repository;
import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.example.springsocial.comunity.Comunity;

public interface ComunityRepository extends JpaRepository<Comunity, Long> {

	public final static String SELECT_BOARD_LIST_PAGED = ""
			+ "SELECT "
			+ "no,"
			+ "type,"
			+ "title,"
			+ "contents,"
			+ "userid,"
			+ "nickname,"
			+ "created_time,"
			+ "updated_time,"
			+ "counts"
			+ " FROM comunity WHERE 0 < no "
			+ "ORDER BY no DESC LIMIT ?1, ?2";
	
//	Optional<Comunity> findById(Long id);
	
	@Query(value = SELECT_BOARD_LIST_PAGED, nativeQuery = true)
	List<Comunity> findFromTo(
			final Integer objectStartNum,
			final Integer objectEndNum);

	
}

