package com.example.springsocial.comunity.recommend.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class RecommendDTO {
	private int recommendNum;
    private boolean isRecommended;

    public static RecommendDTO noOne() {
    	return RecommendDTO.builder()
    			.recommendNum(0)
    			.isRecommended(false)
    			.build();
    }
}
