package com.example.springsocial.qna.controller;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.example.springsocial.qna.Attachment;
import com.example.springsocial.qna.AttachmentType;
import com.example.springsocial.qna.Qna;
import com.example.springsocial.qna.Service.AttachmentService;
import com.example.springsocial.qna.Service.QnaService;


@CrossOrigin(origins = "http://localhost:3000")
@RestController
@RequestMapping("/api")
public class QnaController {
	
	@Autowired
	private QnaService qnaService;
	@Autowired
	private AttachmentService attachmentService;


	@GetMapping("/qna")
	public ResponseEntity<Map> getAllBoards(@RequestParam(value = "p_num", required=false) Integer p_num) {
		if (p_num == null || p_num <= 0) p_num = 1;
		
		return qnaService.getPagingQna(p_num);
	}

//	@PostMapping("/qna")
//	public Qna createQna(@RequestBody Qna qna) {
//		System.out.println("@PostMapping(\"/qna\")");
//		System.out.println(qna.toString());
//		return qnaService.createBoard(qna);
//	}
	
	@PostMapping("/")
	public ResponseEntity<Qna> createFileQna(@RequestParam(required=false, defaultValue = "*") Qna qna, @RequestPart("file") MultipartFile file) {
	    try {
	    	 System.out.println("Received Qna: " + qna.toString());
	        // 파일 저장
	        List<Attachment> attachments = attachmentService.saveAttachment(
	                Collections.singletonMap(AttachmentType.IMAGE, Collections.singletonList(file)));
	        System.out.println(file);
	        
	        String filename = attachments.get(0).getOriginFilename();
	        String filepath = attachments.get(0).getStoreFilename();
	        
	        System.out.println(filename);
	        // 게시글 생성
	        Qna createdQna = qnaService.createBoard(qna);
	        createdQna.setFilename(filename); // 이미지 파일 이름 설정
	        createdQna.setFilepath(filepath); // 파일 경로 설정

	        return ResponseEntity.ok(createdQna);
	    } catch (IOException e) {
	        e.printStackTrace();
	        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(null);
	    }
	}
	
	@PostMapping(value = "/qna")
	public Qna createQna(@ModelAttribute Qna qna,
	                     @RequestPart(value = "file", required = false) MultipartFile file) throws IOException {
	    if (file != null) {
//	        String fileName = file.getOriginalFilename();
//	        String storeFileName = "path_to_store_file/" + fileName;
//	        System.out.println("Original file name: " + fileName);
//	        System.out.println("Store file name: " + storeFileName);// 파일을 저장할 경로 설정
//	        File dest = new File(storeFileName);
//	        file.transferTo(dest); // 파일 저장

	        // 첨부 파일을 저장하고 파일 정보를 얻어옴
	        List<Attachment> attachments = attachmentService.saveAttachment(
	                Collections.singletonMap(AttachmentType.IMAGE, Collections.singletonList(file)));
	        System.out.println(file);
	        String filename = attachments.get(0).getOriginFilename();
	        String filepath = attachments.get(0).getStoreFilename();
	        qna.setFilename(filename); // 이미지 파일 이름 설정
	        qna.setFilepath(filepath);
//	        qna.setAttachedFiles(attachments);
	        
	        System.out.println(filename);

	        // Qna 객체에 파일 정보 추가
	        
	    }

	    System.out.println("@PostMapping(\"/qna\")");
	    System.out.println(qna.toString());
	    return qnaService.createBoard(qna);
	}
	
	@GetMapping("/qna/{no}")
	public ResponseEntity<Qna> getBoardByno(@PathVariable Integer no) {
		return qnaService.getBoard(no);
	}
	
	@PutMapping("/qna/{no}")
	public ResponseEntity<Qna> updateBoardByno(@PathVariable Integer no, @RequestBody Qna qna) {
		return qnaService.updateBoard(no, qna);
	}
	
	@DeleteMapping("qna/{no}")
	public ResponseEntity<Map<String, Boolean>> deleteBoardByNo(@PathVariable Integer no){
		return qnaService.deleteBoard(no);
	}
	
    

    
    
	
}
