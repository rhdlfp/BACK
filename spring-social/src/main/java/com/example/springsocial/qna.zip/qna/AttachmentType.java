package com.example.springsocial.qna;

public enum AttachmentType {
    IMAGE, GENERAL
}
