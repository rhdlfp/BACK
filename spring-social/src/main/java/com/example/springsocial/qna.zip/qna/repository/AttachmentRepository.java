package com.example.springsocial.qna.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.springsocial.qna.Attachment;

public interface AttachmentRepository extends JpaRepository<Attachment, Long> {
}
